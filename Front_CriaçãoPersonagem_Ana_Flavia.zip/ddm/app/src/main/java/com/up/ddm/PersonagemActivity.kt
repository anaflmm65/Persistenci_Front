package com.up.ddm

class PersonagemActivity {
    fun iniciar() {
        println("Bem-vindo ao sistema de criação de personagens!")

        // Solicitar a escolha da raça
        println("Escolha uma raça: ")
        println("1 - Anão")
        println("2 - Gnomo")
        println("3 - Humano")
        println("4 - Elfo")
        val escolhaRaca = readLine() ?: "1"
        val raca = Raca.criarPorEscolha(escolhaRaca)

        // Solicitar a escolha da classe
        println("Escolha uma classe: ")
        println("1 - Guerreiro (d10)")
        println("2 - Mago (d6)")
        println("3 - Arqueiro (d8)")
        val escolhaClasse = readLine() ?: "1"
        val classe = Classes.criarPorEscolha(escolhaClasse)

        // Cria uma nova instância de Habilidades
        val habilidades = Habilidades()

        // Cria uma nova instância de Personagem
        val personagem = Personagem(raca, classe, habilidades)

        // Exibe as informações do personagem
        println("\nInformações do Personagem:")
        personagem.exibirInformacoesRaca()
        personagem.exibirInformacoesClasse()
        personagem.exibirInformacoesPontosDeVida()
        personagem.exibirHabilidades()

        println("Obrigado por usar o sistema de criação de personagens!")
    }
}

fun main() {
    val activity = PersonagemActivity()
    activity.iniciar()
}
